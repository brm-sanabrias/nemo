<?php
// $Id: pager_wrapper_include.php,v 1.1 2005/07/04 08:08:46 quipo Exp $
require_once 'Pager/Pager.php';
require_once 'Pager/Wrapper.php';
?>