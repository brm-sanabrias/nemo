// Alias main HTML_AJAX functions to shorter names
// See Main.js for License/Author details
var $u = HTML_AJAX_Util;
var $a = HTML_AJAX;
if (!$) {
	var $ = HTML_AJAX_Util.getElement;
}
